
import java.util.*;
    public class Main {
        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);

            String greeting = "HeyHey";

            System.out.println(greeting);



            String new_greeting = ("How's it going?");

            System.out.print(new_greeting);

            final int Account_Checkings = 45;

            Long $AccountSavings = 489L;

            System.out.println(Account_Checkings + $AccountSavings);

            int account_cd = 8000;
            int accountBrother = 500;

            for ( int accountSister = 5;  accountSister < 50;  accountSister++ ) {

                accountSister += 20;
                System.out.print(accountSister + "is all I got");

            }

                 if (int accountSister != int Account_Checkings) {
                     System.out.print("No bueno bruddy");
                 }






    }

        static void myMethod() {
            private int num = 12;
        }

        topFour = ["Warriors", "Kings", "Lakers"]


               static void for (String teams : topFour){
            System.out.println(teams);
            teams.add("x");
           private String x= "Pelicans";
        }

}


